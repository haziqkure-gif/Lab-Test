/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.drivesmart.controller;

import com.drivesmart.model.SessionBean;
import com.drivesmart.dao.SessionDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookSessionServlet")
public class BookSessionServlet extends HttpServlet {
    
    private SessionDAO sessionDAO;
    
    // Initialize DAO when servlet loads
    @Override
    public void init() {
        sessionDAO = new SessionDAO();
    }
    
    // Handle POST requests (form submission)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Step 1: Get form data
        String studentName = request.getParameter("student_name");
        String branchLocation = request.getParameter("branch_location");
        String lessonType = request.getParameter("lesson_type");
        
        // Step 2: Create SessionBean object
        SessionBean session = new SessionBean();
        session.setStudentName(studentName);
        session.setBranchLocation(branchLocation);
        session.setLessonType(lessonType);
        session.setStatus("Booked");  // Default status
        
        // Step 3: Save to database
        boolean success = sessionDAO.bookSession(session);
        
        // Step 4: Redirect on success
        if (success) {
            response.sendRedirect("ScheduleServlet");
        } else {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                              "Failed to book session");
        }
    }
}