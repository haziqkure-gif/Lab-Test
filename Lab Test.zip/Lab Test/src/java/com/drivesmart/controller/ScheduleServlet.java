package com.drivesmart.controller;

import com.drivesmart.model.SessionBean;
import com.drivesmart.dao.SessionDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ScheduleServlet")
public class ScheduleServlet extends HttpServlet {
    
    private SessionDAO sessionDAO;
    
    // Initialize DAO when servlet loads
    @Override
    public void init() {
        sessionDAO = new SessionDAO();
    }
    
    // Handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Step 1: Get all sessions from database
        List<SessionBean> sessionList = sessionDAO.getAllSessions();
        
        // Step 2: Store in request attribute
        request.setAttribute("sessionList", sessionList);
        
        // Step 3: Forward to JSP page
        RequestDispatcher dispatcher = request.getRequestDispatcher("schedule.jsp");
        dispatcher.forward(request, response);
    }
}