/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.drivesmart.dao;



import com.drivesmart.model.SessionBean;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SessionDAO {
    
    // DATABASE CONNECTION DETAILS
    private String jdbcURL = "jdbc:mysql://localhost:3306/drivesmart_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";  // Change if you have password
    
    // METHOD 1: ESTABLISH CONNECTION (5 Marks)
    private Connection getConnection() throws SQLException {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Create and return connection
            return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found", e);
        }
    }
    
    // METHOD 2: INSERT SESSION - bookSession (5 Marks)
    public boolean bookSession(SessionBean session) {
        String sql = "INSERT INTO Training_Sessions (student_name, branch_location, lesson_type, status) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // Set values from SessionBean to SQL
            pstmt.setString(1, session.getStudentName());
            pstmt.setString(2, session.getBranchLocation());
            pstmt.setString(3, session.getLessonType());
            pstmt.setString(4, session.getStatus());
            
            // Execute INSERT
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if successful
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // METHOD 3: RETRIEVE ALL SESSIONS - getAllSessions (5 Marks)
    public List<SessionBean> getAllSessions() {
        List<SessionBean> sessionList = new ArrayList<>();
        String sql = "SELECT * FROM Training_Sessions ORDER BY branch_location ASC";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            // Loop through results and create SessionBean objects
            while (rs.next()) {
                SessionBean session = new SessionBean();
                session.setSessionId(rs.getInt("session_id"));
                session.setStudentName(rs.getString("student_name"));
                session.setBranchLocation(rs.getString("branch_location"));
                session.setLessonType(rs.getString("lesson_type"));
                session.setStatus(rs.getString("status"));
                sessionList.add(session);  // Add to list
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return sessionList;  // Return list of sessions
    }
}