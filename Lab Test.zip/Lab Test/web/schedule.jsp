<%@page import="com.drivesmart.model.SessionBean"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Centralized Schedule - DriveSmart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
        }
        .schedule-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .schedule-card h2 {
            color: #2c3e50;
            margin-bottom: 5px;
        }
        .subtitle {
            color: #7f8c8d;
            margin-bottom: 25px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background: #2c3e50;
            color: white;
            padding: 12px;
            text-align: left;
        }
        td {
            padding: 10px 12px;
            border-bottom: 1px solid #ddd;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .status-booked {
            background: #3498db;
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
        }
        .status-completed {
            background: #27ae60;
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
        }
        .refresh-btn {
            background: #3498db;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        .refresh-btn:hover {
            background: #2980b9;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            color: #3498db;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <%@ include file="header.html" %>
    
    <div class="container">
        <div class="schedule-card">
            <h2>📊 Centralized Training Schedule</h2>
            <div class="subtitle">Real-time sessions across all branches (Ordered by Branch Location)</div>
            
            <button class="refresh-btn" onclick="window.location.reload()">🔄 Refresh Data</button>
            
            <table>
                <thead>
                    <tr>
                        <th>Session ID</th>
                        <th>Student Name</th>
                        <th>Branch Location</th>
                        <th>Lesson Type</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                        List<SessionBean> sessionList = (List<SessionBean>) request.getAttribute("sessionList");
                        if (sessionList != null && !sessionList.isEmpty()) {
                            for (SessionBean sessionItem : sessionList) {
                    %>
                    <tr>
                        <td><%= sessionItem.getSessionId() %></td>
                        <td><%= sessionItem.getStudentName() %></td>
                        <td><%= sessionItem.getBranchLocation() %></td>
                        <td><%= sessionItem.getLessonType() %></td>
                        <td>
                            <span class="status-<%= sessionItem.getStatus().toLowerCase() %>">
                                <%= sessionItem.getStatus() %>
                            </span>
                        </td>
                    </tr>
                    <%
                            }
                        } else {
                    %>
                    <tr>
                        <td colspan="5" class="no-data">📭 No training sessions found. Please book a session.</td>
                    </tr>
                    <%
                        }
                    %>
                </tbody>
            </table>
            
            <div class="back-link">
                <a href="index.jsp">← Back to Home</a>
                &nbsp;|&nbsp;
                <a href="book_session.jsp">+ Book New Session</a>
            </div>
        </div>
    </div>
    
    <%@ include file="footer.jsp" %>
</body>
</html>