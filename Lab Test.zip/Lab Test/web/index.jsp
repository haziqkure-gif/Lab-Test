<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>DriveSmart Academy - Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .nav-menu {
            background: white;
            padding: 30px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .nav-menu h2 {
            color: #2c3e50;
            margin-bottom: 25px;
        }
        .menu-buttons {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        .menu-btn {
            display: inline-block;
            padding: 15px 35px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .menu-btn:hover {
            background: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .menu-btn.schedule {
            background: #27ae60;
        }
        .menu-btn.schedule:hover {
            background: #219a52;
        }
        .info-section {
            background: #ecf0f1;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <%@ include file="header.html" %>
    
    <div class="container">
        <div class="nav-menu">
            <h2>📋 Central Navigation Menu</h2>
            <div class="menu-buttons">
                <a href="book_session.jsp" class="menu-btn">📅 Book New Session</a>
                <a href="ScheduleServlet" class="menu-btn schedule">📊 View Schedule Dashboard</a>
            </div>
        </div>
        
        <div class="info-section">
            <h3>Welcome to DriveSmart Integrated Academy</h3>
            <p>Book your driving lessons at any branch nationwide and view real-time schedules.</p>
            <p><strong>Available Branches:</strong> Kuala Lumpur | Penang | Johor | Selangor | Perak</p>
        </div>
    </div>
    
    <%@ include file="footer.jsp" %>
</body>
</html>