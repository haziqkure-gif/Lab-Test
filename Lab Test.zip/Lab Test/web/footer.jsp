<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <style>
        .footer {
            background-color: #34495e;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 30px;
            border-radius: 0 0 10px 10px;
            font-size: 14px;
        }
        .footer p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="footer">
        <p>&copy; 2025 DriveSmart Academy - All Rights Reserved</p>
        <p>Current Server Date & Time: <strong><%= new java.util.Date() %></strong></p>
    </div>
</body>
</html>