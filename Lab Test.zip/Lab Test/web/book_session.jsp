<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Book Driving Session - DriveSmart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 600px;
            margin: 30px auto;
            padding: 20px;
        }
        .form-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .form-card h2 {
            color: #2c3e50;
            margin-bottom: 25px;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #333;
        }
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .submit-btn {
            background: #3498db;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            font-weight: bold;
        }
        .submit-btn:hover {
            background: #2980b9;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #7f8c8d;
        }
        .back-link a {
            color: #3498db;
            text-decoration: none;
        }
        .required {
            color: red;
        }
    </style>
</head>
<body>
    <%@ include file="header.html" %>
    
    <div class="container">
        <div class="form-card">
            <h2>📝 Register New Driving Lesson</h2>
            
            <form method="POST" action="BookSessionServlet">
                <div class="form-group">
                    <label>Student Name <span class="required">*</span></label>
                    <input type="text" name="student_name" placeholder="Enter your full name" required>
                </div>
                
                <div class="form-group">
                    <label>Branch Location <span class="required">*</span></label>
                    <select name="branch_location" required>
                        <option value="">-- Select Branch --</option>
                        <option value="Kuala Lumpur">Kuala Lumpur</option>
                        <option value="Penang">Penang</option>
                        <option value="Johor">Johor</option>
                        <option value="Selangor">Selangor</option>
                        <option value="Perak">Perak</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Lesson Type <span class="required">*</span></label>
                    <select name="lesson_type" required>
                        <option value="">-- Select Lesson Type --</option>
                        <option value="Manual Car">Manual Car</option>
                        <option value="Automatic Car">Automatic Car</option>
                        <option value="Motorcycle">Motorcycle</option>
                    </select>
                </div>
                
                <button type="submit" class="submit-btn">✅ Book Session Now</button>
            </form>
            
            <div class="back-link">
                <a href="index.jsp">← Back to Home</a>
            </div>
        </div>
    </div>
    
    <%@ include file="footer.jsp" %>
</body>
</html>